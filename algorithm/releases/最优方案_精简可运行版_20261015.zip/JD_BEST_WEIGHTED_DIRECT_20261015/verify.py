"""Independent CSV/geometry validation; no solver code is imported."""
from pathlib import Path
from math import hypot, isclose, isfinite
import csv
import hashlib
import io
import json

ROOT = Path(__file__).resolve().parent

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def verify_package():
    manifest = read(ROOT / 'PACKAGE_MANIFEST.json')
    for name, spec in manifest['files'].items():
        p = ROOT / name
        raw = p.read_bytes()
        if len(raw) != spec['bytes'] or hashlib.sha256(raw).hexdigest() != spec['sha256']:
            raise ValueError('Package file changed: ' + name)
    return len(manifest['files'])

def verify_result(path=None):
    cfg = read(ROOT / 'input/run_config.json')
    result = read(path or ROOT / 'result/BEST_RESULT.json')
    raw = (ROOT / 'input/official_tasks.csv').read_bytes()
    if hashlib.sha256(raw).hexdigest() != cfg['input_sha256']:
        raise ValueError('Official input hash mismatch')
    for encoding in ('utf-8-sig', 'gb18030'):
        try:
            text = raw.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise ValueError('Unknown CSV encoding')
    rows = list(csv.reader(io.StringIO(text)))
    tasks = {int(r[0]): tuple(map(float, r[1:6])) for r in rows[1:] if r}
    assert len(tasks) == 200 and set(tasks) == set(range(1, 201))
    assert len(result['routes']) == 8
    assert result['valid'] is True and result['violations'] == []
    problem = result['problem']
    for field, value in [('task_count', 200), ('drone_count', 8), ('capacity', 2),
                         ('max_tasks_per_drone', 25), ('speed_km_per_min', .9), ('open_routes', True)]:
        assert problem[field] == value, field
    expected_homes = ['origin' if h is None else 'station_' + str(h) for h in cfg['drone_homes']]
    assert problem['drone_homes'] == expected_homes
    assert result['relay']['relay_task_count'] == 0
    assert set(result['task_plans']) == {str(t) for t in tasks}
    assert all(p['mode'] == 'DIRECT' and p['leg_ids'] == [] and p['relay_id'] is None
               for p in result['task_plans'].values())
    delivered = {}; picked = set(); total_distance = 0.; per_drone = []
    for a, route in enumerate(result['routes']):
        assert route['drone_id'] == a + 1
        pos = cfg['home_points'][a]; clock = 0.; distance = 0.; carried = set(); own = []
        visits = route['encoded_visits']
        assert len(visits) == 50 and len(route['visits']) == len(visits)
        for k, v in enumerate(visits):
            assert type(v) is int and abs(v) in tasks
            task = abs(v); row = tasks[task]
            point = row[:2] if v > 0 else row[2:4]
            leg = hypot(point[0] - pos[0], point[1] - pos[1])
            distance += leg; clock += leg / .9; pos = point
            if v > 0:
                assert task not in picked
                picked.add(task); carried.add(task)
            else:
                assert task in carried and task not in delivered
                carried.remove(task); delivered[task] = clock; own.append(task)
            assert len(carried) <= 2
            event = route['visits'][k]
            assert event['task_id'] == task and event['leg_id'] is None
            assert event['action'] == ('pickup' if v > 0 else 'delivery')
            assert all(isclose(x, y, abs_tol=1e-8) for x, y in zip(event['location_km'], point))
            assert isclose(event['arrival_time_min'], clock, abs_tol=1e-7)
        assert not carried and len(own) == 25
        late = sum(delivered[t] > tasks[t][4] + 1e-9 for t in own)
        lateness = sum(max(0., delivered[t] - tasks[t][4]) for t in own)
        assert isclose(route['distance_km'], distance, abs_tol=1e-7)
        assert isclose(route['completion_time_min'], clock, abs_tol=1e-7)
        assert route['late_count'] == late and route['task_count'] == 25
        assert isclose(route['total_lateness_min'], lateness, abs_tol=1e-7)
        per_drone.append(dict(drone_id=a+1, on_time=25-late, late=late,
                              distance_km=distance, lateness_min=lateness))
        total_distance += distance
    assert picked == set(tasks) and set(delivered) == set(tasks)
    assert set(result['delivery_times_min']) == {str(t) for t in tasks}
    for task, time in delivered.items():
        assert isclose(result['delivery_times_min'][str(task)], time, abs_tol=1e-7)
    score = dict(late_count=sum(delivered[t] > tasks[t][4] + 1e-9 for t in tasks),
                 total_lateness_min=sum(max(0., delivered[t]-tasks[t][4]) for t in tasks),
                 distance_km=total_distance)
    for key, value in score.items():
        assert isfinite(value) and isclose(value, result['score'][key], abs_tol=1e-7), key
    j = sum(w * score[k] / s for k, w, s in zip(
        ('late_count', 'total_lateness_min', 'distance_km'), cfg['weights'], cfg['scales']))
    return dict(passed=True, score=score, weighted_J=j,
                on_time_count=200-score['late_count'], relay_task_count=0, per_drone=per_drone)

if __name__ == '__main__':
    print(json.dumps(dict(package_files_checked=verify_package(), **verify_result()),
                     ensure_ascii=False, indent=2))
