"""Standalone entry for the one packaged weighted DIRECT method."""
from pathlib import Path
import argparse
from dataclasses import asdict, replace
import json
from math import isclose, isfinite
import sys
from time import perf_counter
from types import MappingProxyType

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'src'))
from verify import read, verify_package, verify_result
import multi_relay_direct_control_v1 as best
import weighted_direct_objective as weighted
from uav_dispatch import alns
from uav_dispatch.cli import result_payload
from uav_dispatch.io import load_tasks_csv
from uav_dispatch.model import Problem, RelayStation, TransportLeg, Score
from uav_dispatch.search import SolverResult
from uav_dispatch.validation import evaluate_solution

def build_problem(cfg):
    tasks = load_tasks_csv(ROOT / 'input/official_tasks.csv')
    stations = tuple(RelayStation(*row) for row in cfg['stations'])
    registry = {}; candidates = {}; counter = max(t.id for t in tasks) + 1
    for task in sorted(tasks, key=lambda t: t.id):
        candidates[task.id] = tuple(s.id for s in stations)
        for station in stations:
            registry[counter] = TransportLeg(counter, task.id, 'RELAY_IN', station.id)
            registry[counter+1] = TransportLeg(counter+1, task.id, 'RELAY_OUT', station.id)
            counter += 2
    full = Problem(tasks=tuple(tasks), drone_count=8, max_tasks_per_drone=25,
                   capacity=2, speed_km_per_min=.9, drone_homes=tuple(cfg['drone_homes']),
                   relay_stations=stations, leg_registry=registry, task_relay_candidates=candidates)
    assert [[p.x,p.y] for p in full.home_points()] == cfg['home_points']
    return full, replace(full, leg_registry={}, task_relay_candidates={})

def main():
    parser = argparse.ArgumentParser(description='当前加权最优直送方案；Python 3.11+，无需第三方包。')
    parser.add_argument('mode', choices=('verify', 'solve'), nargs='?', default='verify')
    parser.add_argument('--seconds', type=float, default=240., help='新运行总预算；不会恢复历史 /goal')
    parser.add_argument('--output', type=Path, default=Path('new_result.json'))
    parser.add_argument('--from-scratch', action='store_true', help='重新构造初解；不保证历史最佳成绩')
    args = parser.parse_args()
    count = verify_package()
    cfg = read(ROOT / 'input/run_config.json')
    full, plain = build_problem(cfg)
    routes = tuple(tuple(r) for r in cfg['initial_routes'])
    checked = evaluate_solution(full, routes, _force_full=True)
    assert checked.valid
    for key, value in cfg['initial_score'].items():
        assert isclose(getattr(checked.score, key), value, abs_tol=1e-8), key
    assert alns._weighted_adapter is weighted
    if args.mode == 'verify':
        print(json.dumps(dict(package_files_checked=count, runtime_imports_ok=True,
                              initial_routes_valid=True, **verify_result()), ensure_ascii=False, indent=2))
        return
    if not isfinite(args.seconds) or args.seconds < 2:
        parser.error('--seconds must be finite and >= 2')
    output = args.output.resolve()
    if output.exists() or output == ROOT or ROOT in output.parents and output.parts[len(ROOT.parts)] in ('src','input','result','evidence','docs'):
        parser.error('Select a new output file; never overwrite the packaged result or sources')
    if not output.parent.is_dir():
        parser.error('Output parent directory must already exist')
    started = perf_counter(); deadline = started + args.seconds - 1.
    if args.from_scratch:
        initial = alns.construct_regret_initial(plain, candidate_limit=48, home_seed=True, home_bias=True)
        routes = initial.routes
    initial_checked = evaluate_solution(full, routes, _force_full=True)
    if not initial_checked.valid:
        raise ValueError('Initial routes are invalid')
    with weighted.objective(Score, cfg['scales'], cfg['weights']):
        outcome = best.refine(full, routes, deadline=deadline, weights=cfg['weights'],
                              scales=cfg['scales'], seed=cfg['seed'], relay_enabled=False,
                              **cfg['parameters'])
        checked = evaluate_solution(plain, outcome['routes'], _force_full=True)
        if not checked.valid or checked.score > initial_checked.score:
            raise ValueError('The complete result failed validation/incumbent guard')
        payload = result_payload(plain, SolverResult(outcome['routes'], checked,
            runtime_seconds=perf_counter()-started, iterations=outcome['iterations'],
            metadata=MappingProxyType(dict(method=cfg['method'], seed=cfg['seed'],
                historical_checkpoint=not args.from_scratch, packaged_launcher=True))),
            source='input/official_tasks.csv')
        payload['problem']['objective_order'] = ['weighted_total_score','late_count','total_lateness_min','distance_km']
        payload['problem']['experiment_objective'] = dict(kind='weighted',weights=cfg['weights'],scales=cfg['scales'])
        payload['weighted_score'] = weighted.scalar(checked.score.late_count,
            checked.score.total_lateness_min, checked.score.distance_km)
        payload['run_budget'] = dict(ceiling_seconds=args.seconds, finalization_reserve_seconds=1.,
            same_original_experiment_harness=False, timing='Standalone solve/final validation/write, imports and initial package checks excluded')
        with output.open('x', encoding='utf-8') as stream:
            json.dump(payload,stream,ensure_ascii=False,indent=2); stream.write('\n')
        elapsed = perf_counter()-started
        print(json.dumps(dict(output=str(output),score=asdict(checked.score),weighted_J=payload['weighted_score'],
                              actual_seconds=elapsed,budget_compliant=elapsed<=args.seconds),ensure_ascii=False,indent=2))

if __name__ == '__main__':
    main()
