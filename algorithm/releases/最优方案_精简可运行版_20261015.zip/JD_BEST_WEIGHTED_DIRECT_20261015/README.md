# 当前加权最优方案：精简可运行版

仅包含本次最佳 DIRECT 运行的算法、数据、结果与说明。Python 3.11+；不需要联网、仓库其他文件或第三方依赖。最先打开 `docs/REPORT.html` 看结果，或按下面命令使用。

## 直接使用

解压，在本目录打开终端（Windows 可将 `python3` 换成 `python`）：

```bash
python3 run.py verify
```

核对文件哈希、完整运行时导入、初始路线与全部200单的最终可行性；不启动搜索。
`python3 verify.py` 还可只用独立的CSV/欧氏几何检查，不导入算法。

```bash
python3 run.py solve --seconds 240 --output new_result.json
```

用本次相同参数、种子和必需初始路线续跑，写入新文件，不覆盖历史最佳。
若要从零构造初解，可增加 `--from-scratch`，其成绩不能与历史追加搜索预算混为一谈。
API：`src/multi_relay_direct_control_v1.py` 中的 `refine(...)`；通常直接用上面的入口即可。
时间限制影响迭代数，机器/版本不同不保证新运行逐字得到同一解；保存的最佳结果可直接读取使用。

## 文件

- `result/BEST_RESULT.json`：原始最佳完整解，逐字保留，含路线和全部送达时刻。
- `result/EXPERIMENT_RESULTS.json`：本次实验指标、预算/实际用时、种子与各阶段结果；`TASK_RESULTS.json`：200单逐项时效；`UAV_RESULTS.json`：8机统计。
- `input/official_tasks.csv`：官方200任务原始数据；`run_config.json`：固定四站、起点、权重、参数及本次必须的初始路线。
- `src/`：本次方法实际导入的16个模块和冻结求解器库19个文件。复用辅助函数的历史模块名保留以维持源码原样，不附历史实验。
- `docs/REPORT.md` / `REPORT.html`：仅本次最佳结果的报告摘编、算法说明、指标和适用边界。
- `evidence/`：只抽取本次DIRECT审计与运行记录，并记录逐文件源码来源。
- `PACKAGE_MANIFEST.json`：包内文件SHA256清单。生成的新结果放在包外或目录根部，不列入历史清单。

本方案实际中继0单，不是中继获胜结果。J为研究加权偏好，不是题目官方分数；“最优”指当前保存的最低J合法终解，未证明数学全局最优。本次历史结果来自强解追加搜索，不能称为从零240秒获得。`/goal` 保持暂停；打包没有恢复优化任务。
